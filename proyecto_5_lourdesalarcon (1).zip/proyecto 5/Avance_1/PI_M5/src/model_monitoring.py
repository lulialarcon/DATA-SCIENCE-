# model_monitoring.py
import os
import time
import pandas as pd
import requests
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from evidently import Report 
from evidently.metrics import DatasetDriftMetric
from evidently.presets import DataDriftPreset
from sklearn.model_selection import train_test_split
import numpy as np
from scipy import stats
from scipy.spatial.distance import jensenshannon
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score, confusion_matrix
import plotly.figure_factory as ff
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# ================================
# 1. Configuración
# ================================
API_URL = "http://localhost:8000/predict_batch"
DATASET_PATH = "./Base_de_datos.xlsx"
MONITOR_LOG = "./monitoring_log.csv"
DRIFT_THRESHOLD_PSI = 0.1
DRIFT_THRESHOLD_JS = 0.1
DRIFT_THRESHOLD_KS = 0.05

# ================================
# 2. Cargar dataset y dividir
# ================================
@st.cache_data
def load_data():
    """
    Carga los datos desde un archivo Excel y los divide en referencia y actual
    """
    try:
        # Cargar datos desde el archivo Excel
        if not os.path.exists(DATASET_PATH):
            st.error(f"❌ Archivo no encontrado: {DATASET_PATH}")
            st.error("Por favor, asegúrate de que el archivo Base_de_datos.xlsx existe en el directorio actual.")
            st.stop()
        
        df = pd.read_excel(DATASET_PATH)
        
        # Verificar que tenemos la columna objetivo
        target = "Pago_atiempo"
        
        if target not in df.columns:
            st.error(f"❌ Error: La columna objetivo '{target}' no se encuentra en el dataset.")
            st.error(f"Columnas disponibles: {', '.join(df.columns.tolist())}")
            st.stop()
        
        # Dividir en referencia (80%) y actual (20%)
        X = df.drop(columns=[target])
        y = df[target]
        
        # Asegurar que las columnas categóricas sean tratadas correctamente
        categorical_cols = X.select_dtypes(include=['object', 'category']).columns
        for col in categorical_cols:
            X[col] = X[col].astype('category')
        
        X_ref, X_new, y_ref, y_new = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        st.sidebar.success(f"✅ Datos cargados exitosamente")
        st.sidebar.info(f"• Total registros: {len(df)}")
        st.sidebar.info(f"• Variables: {len(X.columns)}")
        st.sidebar.info(f"• Referencia: {len(X_ref)} registros")
        st.sidebar.info(f"• Actual: {len(X_new)} registros")
        
        return X_ref, X_new, y_ref, y_new, df, X.columns.tolist()
        
    except Exception as e:
        st.error(f"❌ Error al cargar datos: {str(e)}")
        st.stop()

# ================================
# 3. Métricas de Data Drift
# ================================
def calculate_ks_test(ref_data, curr_data, feature):
    """Calcula el test de Kolmogorov-Smirnov para variables numéricas"""
    try:
        if pd.api.types.is_numeric_dtype(ref_data[feature]):
            # Eliminar valores nulos
            ref_vals = ref_data[feature].dropna()
            curr_vals = curr_data[feature].dropna()
            
            if len(ref_vals) == 0 or len(curr_vals) == 0:
                return None, None
            
            statistic, p_value = stats.ks_2samp(ref_vals, curr_vals)
            return statistic, p_value
    except Exception as e:
        st.warning(f"Advertencia en KS para {feature}: {str(e)}")
        return None, None
    return None, None

def calculate_psi(ref_data, curr_data, feature, bins=10):
    """Calcula el Population Stability Index"""
    try:
        if pd.api.types.is_numeric_dtype(ref_data[feature]):
            # Combinar datos para definir bins
            combined = pd.concat([ref_data[feature], curr_data[feature]], ignore_index=True).dropna()
            
            if len(combined) < 2:
                return 0
            
            # Crear bins usando percentiles para mejor estabilidad
            bins_edges = np.percentile(combined, np.linspace(0, 100, bins + 1))
            bins_edges = np.unique(bins_edges)  # Remover duplicados
            
            if len(bins_edges) < 2:
                return 0
            
            # Contar ocurrencias en cada bin
            ref_counts, _ = np.histogram(ref_data[feature].dropna(), bins=bins_edges)
            curr_counts, _ = np.histogram(curr_data[feature].dropna(), bins=bins_edges)
            
            # Calcular proporciones
            ref_prop = ref_counts / len(ref_data)
            curr_prop = curr_counts / len(curr_data)
            
            # Suavizar para evitar divisiones por cero
            epsilon = 1e-10
            ref_prop = np.where(ref_prop == 0, epsilon, ref_prop)
            curr_prop = np.where(curr_prop == 0, epsilon, curr_prop)
            
            # Calcular PSI
            psi = np.sum((curr_prop - ref_prop) * np.log(curr_prop / ref_prop))
            return psi
            
    except Exception as e:
        st.warning(f"Advertencia en PSI para {feature}: {str(e)}")
        return None
    return None

def calculate_js_divergence(ref_data, curr_data, feature, bins=10):
    """Calcula la divergencia de Jensen-Shannon"""
    try:
        if pd.api.types.is_numeric_dtype(ref_data[feature]):
            # Combinar datos
            combined = pd.concat([ref_data[feature], curr_data[feature]], ignore_index=True).dropna()
            
            if len(combined) < 2:
                return 0
            
            # Crear bins usando percentiles
            bins_edges = np.percentile(combined, np.linspace(0, 100, bins + 1))
            bins_edges = np.unique(bins_edges)
            
            if len(bins_edges) < 2:
                return 0
            
            # Calcular distribuciones de probabilidad
            P, _ = np.histogram(ref_data[feature].dropna(), bins=bins_edges, density=True)
            Q, _ = np.histogram(curr_data[feature].dropna(), bins=bins_edges, density=True)
            
            # Suavizar
            epsilon = 1e-10
            P = P + epsilon
            Q = Q + epsilon
            P = P / np.sum(P)
            Q = Q / np.sum(Q)
            
            # Calcular JS Divergence
            M = 0.5 * (P + Q)
            js = 0.5 * (stats.entropy(P, M) + stats.entropy(Q, M))
            return js
            
    except Exception as e:
        st.warning(f"Advertencia en JS Divergence para {feature}: {str(e)}")
        return None
    return None

def calculate_chi_square(ref_data, curr_data, feature):
    """Calcula chi-cuadrado para variables categóricas"""
    try:
        if pd.api.types.is_categorical_dtype(ref_data[feature]) or \
           pd.api.types.is_object_dtype(ref_data[feature]):
            
            # Obtener todas las categorías
            ref_series = ref_data[feature].dropna()
            curr_series = curr_data[feature].dropna()
            
            if len(ref_series) == 0 or len(curr_series) == 0:
                return None, None
            
            all_categories = set(ref_series.unique()) | set(curr_series.unique())
            
            # Crear tabla de contingencia
            ref_counts = ref_series.value_counts().reindex(all_categories, fill_value=0)
            curr_counts = curr_series.value_counts().reindex(all_categories, fill_value=0)
            
            # Calcular chi-cuadrado
            chi2, p_value, _, _ = stats.chi2_contingency([ref_counts, curr_counts])
            return chi2, p_value
            
    except Exception as e:
        st.warning(f"Advertencia en Chi-square para {feature}: {str(e)}")
        return None, None
    return None, None

def calculate_wasserstein_distance(ref_data, curr_data, feature):
    """Calcula la distancia de Wasserstein para variables numéricas"""
    try:
        if pd.api.types.is_numeric_dtype(ref_data[feature]):
            ref_vals = ref_data[feature].dropna()
            curr_vals = curr_data[feature].dropna()
            
            if len(ref_vals) == 0 or len(curr_vals) == 0:
                return None
            
            # Ordenar valores
            ref_sorted = np.sort(ref_vals)
            curr_sorted = np.sort(curr_vals)
            
            # Interpolación para igualar tamaños
            if len(ref_sorted) != len(curr_sorted):
                x = np.linspace(0, 1, max(len(ref_sorted), len(curr_sorted)))
                ref_sorted = np.interp(x, np.linspace(0, 1, len(ref_sorted)), ref_sorted)
                curr_sorted = np.interp(x, np.linspace(0, 1, len(curr_sorted)), curr_sorted)
            
            # Calcular distancia de Wasserstein
            wasserstein = np.mean(np.abs(ref_sorted - curr_sorted))
            return wasserstein
            
    except Exception as e:
        st.warning(f"Advertencia en Wasserstein para {feature}: {str(e)}")
        return None
    return None

def calculate_all_drift_metrics(ref_data, curr_data):
    """Calcula todas las métricas de drift para cada feature"""
    drift_metrics = {}
    
    for feature in ref_data.columns:
        if feature not in curr_data.columns:
            continue
            
        metrics = {}
        
        # Determinar tipo de variable
        is_numeric = pd.api.types.is_numeric_dtype(ref_data[feature])
        is_categorical = pd.api.types.is_categorical_dtype(ref_data[feature]) or \
                        pd.api.types.is_object_dtype(ref_data[feature])
        
        # KS Test (solo numéricas)
        if is_numeric:
            ks_stat, ks_p = calculate_ks_test(ref_data, curr_data, feature)
            if ks_stat is not None:
                metrics['ks_statistic'] = ks_stat
                metrics['ks_p_value'] = ks_p
                metrics['ks_drift'] = ks_p < DRIFT_THRESHOLD_KS
                metrics['ks_drift_severity'] = 'Alto' if ks_p < 0.01 else 'Medio' if ks_p < 0.05 else 'Bajo'
        
        # PSI (solo numéricas)
        if is_numeric:
            psi = calculate_psi(ref_data, curr_data, feature)
            if psi is not None:
                metrics['psi'] = psi
                metrics['psi_drift'] = psi > DRIFT_THRESHOLD_PSI
                if psi < 0.1:
                    metrics['psi_risk'] = 'Bajo'
                elif psi < 0.25:
                    metrics['psi_risk'] = 'Medio'
                else:
                    metrics['psi_risk'] = 'Alto'
        
        # JS Divergence (solo numéricas)
        if is_numeric:
            js = calculate_js_divergence(ref_data, curr_data, feature)
            if js is not None:
                metrics['js_divergence'] = js
                metrics['js_drift'] = js > DRIFT_THRESHOLD_JS
                metrics['js_risk'] = 'Alto' if js > 0.2 else 'Medio' if js > 0.1 else 'Bajo'
        
        # Chi-square (solo categóricas)
        if is_categorical:
            chi2, chi_p = calculate_chi_square(ref_data, curr_data, feature)
            if chi2 is not None:
                metrics['chi2_statistic'] = chi2
                metrics['chi2_p_value'] = chi_p
                metrics['chi2_drift'] = chi_p < DRIFT_THRESHOLD_KS
                metrics['chi2_risk'] = 'Alto' if chi_p < 0.01 else 'Medio' if chi_p < 0.05 else 'Bajo'
        
        # Wasserstein Distance (solo numéricas)
        if is_numeric:
            wass = calculate_wasserstein_distance(ref_data, curr_data, feature)
            if wass is not None:
                metrics['wasserstein'] = wass
        
        # Estadísticas básicas
        if is_numeric:
            metrics['ref_mean'] = ref_data[feature].mean()
            metrics['curr_mean'] = curr_data[feature].mean()
            metrics['ref_std'] = ref_data[feature].std()
            metrics['curr_std'] = curr_data[feature].std()
            metrics['mean_change_pct'] = abs((metrics['curr_mean'] - metrics['ref_mean']) / metrics['ref_mean'] * 100) if metrics['ref_mean'] != 0 else 0
        
        drift_metrics[feature] = metrics
    
    return drift_metrics

def get_drift_summary(drift_metrics):
    """Resumen general del drift"""
    summary = {
        'total_features': len(drift_metrics),
        'features_with_drift': 0,
        'high_risk_features': 0,
        'medium_risk_features': 0,
        'low_risk_features': 0,
        'avg_psi': 0,
        'avg_js': 0,
        'drift_percentage': 0
    }
    
    psi_values = []
    js_values = []
    
    for feature, metrics in drift_metrics.items():
        has_drift = False
        
        # Verificar cualquier tipo de drift
        if any(key.endswith('_drift') and metrics.get(key) for key in metrics):
            has_drift = True
            summary['features_with_drift'] += 1
        
        # Clasificar por riesgo
        if metrics.get('psi_risk') == 'Alto' or metrics.get('js_risk') == 'Alto' or metrics.get('ks_drift_severity') == 'Alto':
            summary['high_risk_features'] += 1
        elif metrics.get('psi_risk') == 'Medio' or metrics.get('js_risk') == 'Medio' or metrics.get('ks_drift_severity') == 'Medio':
            summary['medium_risk_features'] += 1
        else:
            summary['low_risk_features'] += 1
        
        # Acumular métricas
        if 'psi' in metrics:
            psi_values.append(metrics['psi'])
        if 'js_divergence' in metrics:
            js_values.append(metrics['js_divergence'])
    
    # Calcular promedios
    if psi_values:
        summary['avg_psi'] = np.mean(psi_values)
    if js_values:
        summary['avg_js'] = np.mean(js_values)
    
    if summary['total_features'] > 0:
        summary['drift_percentage'] = (summary['features_with_drift'] / summary['total_features']) * 100
    
    return summary

# ================================
# 4. API para predicciones
# ================================
def get_predictions(X_batch: pd.DataFrame):
    """Obtiene predicciones del modelo a través de la API"""
    try:
        # Convertir DataFrame a lista de diccionarios
        records = X_batch.to_dict(orient='records')
        payload = {"batch": records}
        
        # Enviar solicitud a la API
        response = requests.post(API_URL, json=payload, timeout=30)
        response.raise_for_status()
        result = response.json()
        
        if "predictions" in result:
            return result["predictions"]
        elif "error" in result:
            st.error(f"❌ Error de API: {result['error']}")
            return None
        else:
            st.error("❌ Respuesta de API no contiene 'predictions'")
            return None
            
    except requests.exceptions.ConnectionError:
        st.error("❌ No se pudo conectar con la API. Asegúrate de que el servidor esté ejecutándose en http://localhost:8000")
        return None
    except requests.exceptions.Timeout:
        st.error("❌ Timeout al conectar con la API")
        return None
    except Exception as e:
        st.error(f"❌ Error conectando con la API: {e}")
        return None

# ================================
# 5. Guardar logs con timestamp
# ================================
def log_predictions(X_batch, preds, y_true=None):
    """Guarda las predicciones en un archivo de log"""
    try:
        log_df = X_batch.copy()
        log_df["prediction"] = preds
        log_df["timestamp"] = pd.Timestamp.now()
        log_df["date"] = pd.Timestamp.now().date()
        log_df["hour"] = pd.Timestamp.now().hour
        
        # Si hay valores reales, agregarlos
        if y_true is not None and len(y_true) == len(preds):
            log_df["actual"] = y_true.values
        
        # Asegurar que el directorio existe
        os.makedirs(os.path.dirname(os.path.abspath(MONITOR_LOG)), exist_ok=True)
        
        # Guardar o actualizar log
        if os.path.exists(MONITOR_LOG):
            try:
                existing_log = pd.read_csv(MONITOR_LOG)
                updated_log = pd.concat([existing_log, log_df], ignore_index=True)
                updated_log.to_csv(MONITOR_LOG, index=False)
            except:
                log_df.to_csv(MONITOR_LOG, index=False)
        else:
            log_df.to_csv(MONITOR_LOG, index=False)
            
        return True
        
    except Exception as e:
        st.error(f"❌ Error guardando log: {e}")
        return False

# ================================
# 6. Reporte Evidently
# ================================
def generate_drift_report(ref_data, new_data):
    """Genera reporte de drift usando Evidently"""
    try:
        report = Report(metrics=[DataDriftPreset()])
        report.run(reference_data=ref_data, current_data=new_data)
        return report
    except Exception as e:
        st.warning(f"⚠️ No se pudo generar reporte Evidently: {e}")
        return None

# ================================
# 7. Visualizaciones
# ================================
def create_drift_visualizations(drift_metrics, summary):
    """Crea visualizaciones para el análisis de drift"""
    
    # 1. Gráfico de barras de métricas de drift por feature
    features = list(drift_metrics.keys())
    psi_values = [drift_metrics[f].get('psi', 0) for f in features]
    js_values = [drift_metrics[f].get('js_divergence', 0) for f in features]
    
    fig_metrics = go.Figure(data=[
        go.Bar(name='PSI', x=features, y=psi_values, marker_color='blue'),
        go.Bar(name='JS Divergence', x=features, y=js_values, marker_color='orange')
    ])
    
    fig_metrics.update_layout(
        title='Métricas de Drift por Variable',
        xaxis_title='Variables',
        yaxis_title='Valor',
        barmode='group',
        height=400
    )
    
    # 2. Gráfico de radar para resumen
    categories = ['% Drift', 'Riesgo Alto', 'Riesgo Medio', 'Riesgo Bajo', 'PSI Promedio', 'JS Promedio']
    
    fig_radar = go.Figure(data=go.Scatterpolar(
        r=[summary['drift_percentage'], 
           summary['high_risk_features'],
           summary['medium_risk_features'],
           summary['low_risk_features'],
           summary['avg_psi'] * 10,  # Escalar para mejor visualización
           summary['avg_js'] * 10],
        theta=categories,
        fill='toself',
        line_color='blue'
    ))
    
    fig_radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100]
            )),
        showlegend=False,
        title='Resumen de Drift - Vista Radar',
        height=400
    )
    
    # 3. Heatmap de correlación de drifts
    drift_matrix = []
    for feature in features:
        row = []
        for metric in ['psi_drift', 'js_drift', 'ks_drift', 'chi2_drift']:
            if metric in drift_metrics[feature]:
                row.append(1 if drift_metrics[feature][metric] else 0)
            else:
                row.append(0)
        drift_matrix.append(row)
    
    fig_heatmap = ff.create_annotated_heatmap(
        z=drift_matrix,
        x=['PSI Drift', 'JS Drift', 'KS Drift', 'Chi2 Drift'],
        y=features,
        colorscale='Reds',
        showscale=True
    )
    
    fig_heatmap.update_layout(
        title='Mapa de Calor de Drift por Variable y Métrica',
        height=500
    )
    
    return fig_metrics, fig_radar, fig_heatmap

def create_distribution_comparison(ref_data, curr_data, feature):
    """Crea gráfico de comparación de distribuciones"""
    fig = go.Figure()
    
    # Histograma de referencia
    fig.add_trace(go.Histogram(
        x=ref_data[feature].dropna(),
        name='Referencia',
        opacity=0.7,
        nbinsx=30,
        marker_color='blue',
        histnorm='probability density'
    ))
    
    # Histograma actual
    fig.add_trace(go.Histogram(
        x=curr_data[feature].dropna(),
        name='Actual',
        opacity=0.7,
        nbinsx=30,
        marker_color='orange',
        histnorm='probability density'
    ))
    
    # KDE suavizado
    try:
        from scipy.stats import gaussian_kde
        
        ref_kde = gaussian_kde(ref_data[feature].dropna())
        curr_kde = gaussian_kde(curr_data[feature].dropna())
        
        x_range = np.linspace(
            min(ref_data[feature].min(), curr_data[feature].min()),
            max(ref_data[feature].max(), curr_data[feature].max()),
            100
        )
        
        fig.add_trace(go.Scatter(
            x=x_range,
            y=ref_kde(x_range),
            name='KDE Referencia',
            line=dict(color='darkblue', width=2),
            mode='lines'
        ))
        
        fig.add_trace(go.Scatter(
            x=x_range,
            y=curr_kde(x_range),
            name='KDE Actual',
            line=dict(color='darkorange', width=2),
            mode='lines'
        ))
    except:
        pass
    
    fig.update_layout(
        title=f'Comparación de Distribuciones: {feature}',
        xaxis_title=feature,
        yaxis_title='Densidad',
        barmode='overlay',
        height=400
    )
    
    return fig

# ================================
# 8. Análisis temporal
# ================================
def analyze_temporal_drift(log_data, feature, window_days=7):
    """Analiza drift temporal para una variable específica"""
    try:
        if 'timestamp' not in log_data.columns or feature not in log_data.columns:
            return None
        
        log_data['timestamp'] = pd.to_datetime(log_data['timestamp'])
        log_data['date'] = log_data['timestamp'].dt.date
        
        # Agrupar por día
        daily_stats = log_data.groupby('date')[feature].agg(['mean', 'std', 'count']).reset_index()
        
        if len(daily_stats) < 2:
            return None
        
        # Calcular rolling statistics
        daily_stats['rolling_mean'] = daily_stats['mean'].rolling(window=min(window_days, len(daily_stats))).mean()
        daily_stats['rolling_std'] = daily_stats['std'].rolling(window=min(window_days, len(daily_stats))).std()
        
        # Crear gráfico temporal
        fig = go.Figure()
        
        # Media diaria
        fig.add_trace(go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['mean'],
            mode='markers',
            name='Media Diaria',
            marker=dict(color='blue', size=8)
        ))
        
        # Media móvil
        fig.add_trace(go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['rolling_mean'],
            mode='lines',
            name=f'Media Móvil ({window_days} días)',
            line=dict(color='red', width=3)
        ))
        
        # Banda de desviación estándar
        fig.add_trace(go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['rolling_mean'] + daily_stats['rolling_std'],
            mode='lines',
            name='+1 Desv',
            line=dict(color='gray', width=1, dash='dash'),
            showlegend=False
        ))
        
        fig.add_trace(go.Scatter(
            x=daily_stats['date'],
            y=daily_stats['rolling_mean'] - daily_stats['rolling_std'],
            mode='lines',
            name='-1 Desv',
            fill='tonexty',
            line=dict(color='gray', width=1, dash='dash'),
            showlegend=False
        ))
        
        fig.update_layout(
            title=f'Evolución Temporal: {feature}',
            xaxis_title='Fecha',
            yaxis_title='Valor',
            height=400
        )
        
        return fig, daily_stats
        
    except Exception as e:
        st.warning(f"⚠️ Error en análisis temporal: {e}")
        return None

# ================================
# 9. Recomendaciones
# ================================
def generate_recommendations(drift_summary, drift_metrics):
    """Genera recomendaciones basadas en el análisis de drift"""
    recommendations = []
    warnings = []
    actions = []
    
    # Analizar severidad general
    if drift_summary['drift_percentage'] > 30:
        recommendations.append("🚨 **ALERTA CRÍTICA**: Más del 30% de las variables muestran drift significativo.")
        actions.append("Retraining inmediato del modelo requerido")
        warnings.append("El desempeño del modelo puede estar comprometido")
    
    elif drift_summary['drift_percentage'] > 15:
        recommendations.append("⚠️ **ALERTA**: Entre 15-30% de las variables muestran drift.")
        actions.append("Considerar retraining en el próximo ciclo")
        warnings.append("Monitorear métricas de desempeño cuidadosamente")
    
    else:
        recommendations.append("✅ **ESTABLE**: Menos del 15% de las variables muestran drift.")
        actions.append("Continuar con monitoreo regular")
    
    # Analizar variables de alto riesgo
    high_risk_features = []
    for feature, metrics in drift_metrics.items():
        if (metrics.get('psi_risk') == 'Alto' or 
            metrics.get('js_risk') == 'Alto' or 
            metrics.get('ks_drift_severity') == 'Alto'):
            high_risk_features.append(feature)
    
    if high_risk_features:
        recommendations.append(f"🔴 **Variables de Alto Riesgo**: {', '.join(high_risk_features[:5])}")
        actions.append(f"Revisar y validar las variables: {', '.join(high_risk_features[:3])}")
        warnings.append(f"Las variables de alto riesgo pueden afectar significativamente las predicciones")
    
    # Verificar cambios en estadísticas
    for feature, metrics in drift_metrics.items():
        if 'mean_change_pct' in metrics and metrics['mean_change_pct'] > 50:
            recommendations.append(f"📊 Cambio significativo en {feature}: {metrics['mean_change_pct']:.1f}% en la media")
    
    return recommendations, warnings, actions

# ================================
# 10. Streamlit UI Principal
# ================================
def main():
    st.set_page_config(
        page_title="Sistema de Monitoreo de Modelo",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Título y descripción
    st.title("📊 Sistema de Monitoreo de Modelo - Detección de Data Drift")
    st.markdown("""
    Esta aplicación monitorea el desempeño del modelo y detecta cambios en la distribución de los datos (data drift) 
    que puedan afectar la calidad de las predicciones.
    """)
    
    # Sidebar
    with st.sidebar:
        st.header("⚙️ Configuración")
        
        # Cargar datos
        if st.button("🔄 Cargar Datos", type="primary", use_container_width=True):
            st.session_state.data_loaded = False
            st.rerun()
        
        if 'data_loaded' not in st.session_state:
            with st.spinner("Cargando datos..."):
                try:
                    X_ref, X_new, y_ref, y_new, full_df, all_features = load_data()
                    st.session_state.X_ref = X_ref
                    st.session_state.X_new = X_new
                    st.session_state.y_ref = y_ref
                    st.session_state.y_new = y_new
                    st.session_state.full_df = full_df
                    st.session_state.all_features = all_features
                    st.session_state.data_loaded = True
                    st.success("✅ Datos cargados!")
                except Exception as e:
                    st.error(f"Error: {e}")
                    st.stop()
        
        if st.session_state.get('data_loaded', False):
            st.divider()
            st.header("🎯 Muestreo y Predicciones")
            
            sample_size = st.slider(
                "Tamaño de muestra para predicciones:",
                min_value=10,
                max_value=500,
                value=100,
                step=10
            )
            
            update_freq = st.selectbox(
                "Frecuencia de monitoreo:",
                ["Manual", "Cada 5 minutos", "Cada 30 minutos", "Cada hora", "Cada 6 horas", "Diario"]
            )
            
            # Botón para generar predicciones
            if st.button("🚀 Generar Predicciones", type="secondary", use_container_width=True):
                with st.spinner("Generando predicciones..."):
                    try:
                        sample = X_new.sample(n=min(sample_size, len(X_new)), random_state=int(time.time()))
                        y_sample = y_new.loc[sample.index] if hasattr(y_new, 'loc') else None
                        preds = get_predictions(sample)
                        
                        if preds:
                            if log_predictions(sample, preds, y_sample):
                                st.success(f"✅ {len(preds)} predicciones agregadas al log")
                                time.sleep(1)
                                st.rerun()
                    except Exception as e:
                        st.error(f"Error: {e}")
            
            st.divider()
            st.header("📈 Configuración de Drift")
            
            # Umbrales de drift
            st.subheader("Umbrales de Alerta")
            psi_threshold = st.slider("Umbral PSI:", 0.01, 0.5, 0.1, 0.01)
            js_threshold = st.slider("Umbral JS Divergence:", 0.01, 0.5, 0.1, 0.01)
            
            global DRIFT_THRESHOLD_PSI, DRIFT_THRESHOLD_JS
            DRIFT_THRESHOLD_PSI = psi_threshold
            DRIFT_THRESHOLD_JS = js_threshold
    
    # Contenido principal
    if st.session_state.get('data_loaded', False):
        X_ref = st.session_state.X_ref
        X_new = st.session_state.X_new
        y_ref = st.session_state.y_ref
        y_new = st.session_state.y_new
        all_features = st.session_state.all_features
        
        # Pestañas principales
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Dashboard", 
            "⚠️ Análisis de Drift", 
            "📈 Evolución Temporal", 
            "🎯 Performance", 
            "📋 Logs"
        ])
        
        with tab1:
            st.header("Dashboard de Monitoreo")
            
            # Verificar si hay logs
            if os.path.exists(MONITOR_LOG):
                logged_data = pd.read_csv(MONITOR_LOG)
                
                # Métricas principales
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    total_preds = len(logged_data)
                    st.metric("Total Predicciones", f"{total_preds:,}")
                
                with col2:
                    if 'prediction' in logged_data.columns:
                        pred_mean = logged_data['prediction'].mean()
                        st.metric("Predicción Promedio", f"{pred_mean:.3f}")
                
                with col3:
                    if 'prediction' in logged_data.columns:
                        pred_std = logged_data['prediction'].std()
                        st.metric("Desviación Estándar", f"{pred_std:.3f}")
                
                with col4:
                    if 'prediction' in logged_data.columns:
                        positive_rate = (logged_data['prediction'] > 0.5).mean() * 100
                        st.metric("Tasa Positiva", f"{positive_rate:.1f}%")
                
                # Análisis de drift
                st.subheader("🔍 Análisis Rápido de Data Drift")
                
                if len(logged_data) > 10:
                    current_data = logged_data.drop(columns=['prediction', 'timestamp', 'actual', 'date', 'hour'], errors='ignore')
                    
                    with st.spinner("Calculando métricas de drift..."):
                        drift_metrics = calculate_all_drift_metrics(X_ref, current_data)
                        drift_summary = get_drift_summary(drift_metrics)
                    
                    # Mostrar semáforo de estado
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        if drift_summary['drift_percentage'] > 30:
                            st.error(f"🚨 Drift Crítico: {drift_summary['drift_percentage']:.1f}%")
                        elif drift_summary['drift_percentage'] > 15:
                            st.warning(f"⚠️ Drift Moderado: {drift_summary['drift_percentage']:.1f}%")
                        else:
                            st.success(f"✅ Drift Bajo: {drift_summary['drift_percentage']:.1f}%")
                    
                    with col2:
                        st.metric("Variables con Drift", drift_summary['features_with_drift'])
                    
                    with col3:
                        st.metric("Variables de Alto Riesgo", drift_summary['high_risk_features'])
                    
                    # Recomendaciones
                    st.subheader("💡 Recomendaciones")
                    recommendations, warnings, actions = generate_recommendations(drift_summary, drift_metrics)
                    
                    for rec in recommendations:
                        st.info(rec)
                    
                    if warnings:
                        with st.expander("⚠️ Advertencias"):
                            for warn in warnings:
                                st.warning(warn)
                    
                    if actions:
                        with st.expander("🎯 Acciones Recomendadas"):
                            for action in actions:
                                st.success(action)
                
            else:
                st.info("📝 No hay datos de monitoreo aún. Usa el botón 'Generar Predicciones' para iniciar.")
        
        with tab2:
            st.header("Análisis Detallado de Data Drift")
            
            if os.path.exists(MONITOR_LOG) and len(pd.read_csv(MONITOR_LOG)) > 10:
                logged_data = pd.read_csv(MONITOR_LOG)
                current_data = logged_data.drop(columns=['prediction', 'timestamp', 'actual', 'date', 'hour'], errors='ignore')
                
                # Seleccionar variables para análisis
                st.subheader("Selección de Variables")
                
                selected_features = st.multiselect(
                    "Seleccionar variables para análisis detallado:",
                    all_features,
                    default=all_features[:5] if len(all_features) >= 5 else all_features
                )
                
                if selected_features:
                    # Filtrar datos
                    X_ref_filtered = X_ref[selected_features]
                    current_filtered = current_data[selected_features]
                    
                    # Calcular métricas
                    with st.spinner("Calculando métricas de drift..."):
                        drift_metrics = calculate_all_drift_metrics(X_ref_filtered, current_filtered)
                        drift_summary = get_drift_summary(drift_metrics)
                    
                    # Visualizaciones
                    st.subheader("📈 Visualizaciones")
                    
                    fig_metrics, fig_radar, fig_heatmap = create_drift_visualizations(drift_metrics, drift_summary)
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.plotly_chart(fig_metrics, use_container_width=True)
                    with col2:
                        st.plotly_chart(fig_radar, use_container_width=True)
                    
                    st.plotly_chart(fig_heatmap, use_container_width=True)
                    
                    # Comparación de distribuciones
                    st.subheader("📊 Comparación de Distribuciones")
                    
                    selected_feature = st.selectbox(
                        "Seleccionar variable para comparación detallada:",
                        selected_features
                    )
                    
                    if selected_feature:
                        fig_dist = create_distribution_comparison(X_ref_filtered, current_filtered, selected_feature)
                        st.plotly_chart(fig_dist, use_container_width=True)
                        
                        # Mostrar métricas específicas
                        if selected_feature in drift_metrics:
                            metrics = drift_metrics[selected_feature]
                            
                            col1, col2, col3, col4 = st.columns(4)
                            
                            with col1:
                                if 'psi' in metrics:
                                    st.metric("PSI", f"{metrics['psi']:.4f}")
                            
                            with col2:
                                if 'js_divergence' in metrics:
                                    st.metric("JS Divergence", f"{metrics['js_divergence']:.4f}")
                            
                            with col3:
                                if 'ks_p_value' in metrics:
                                    st.metric("KS p-value", f"{metrics['ks_p_value']:.4f}")
                            
                            with col4:
                                if 'mean_change_pct' in metrics:
                                    st.metric("Cambio en Media", f"{metrics['mean_change_pct']:.1f}%")
                    
                    # Tabla detallada de métricas
                    st.subheader("📋 Métricas por Variable")
                    
                    # Convertir a DataFrame para visualización
                    metrics_list = []
                    for feature, metrics in drift_metrics.items():
                        row = {'Variable': feature}
                        row.update(metrics)
                        metrics_list.append(row)
                    
                    if metrics_list:
                        metrics_df = pd.DataFrame(metrics_list)
                        
                        # Formatear columnas numéricas
                        numeric_cols = metrics_df.select_dtypes(include=[np.number]).columns
                        for col in numeric_cols:
                            if col not in ['Variable']:
                                metrics_df[col] = metrics_df[col].apply(lambda x: f"{x:.4f}" if pd.notnull(x) else "")
                        
                        st.dataframe(metrics_df, use_container_width=True, height=400)
                        
                        # Opción de descarga
                        csv = metrics_df.to_csv(index=False)
                        st.download_button(
                            label="📥 Descargar Métricas",
                            data=csv,
                            file_name=f"drift_metrics_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                            mime="text/csv"
                        )
                    
                    # Reporte Evidently
                    st.subheader("📊 Reporte Evidently")
                    
                    if st.button("Generar Reporte Completo", type="secondary"):
                        with st.spinner("Generando reporte Evidently..."):
                            report = generate_drift_report(X_ref_filtered, current_filtered)
                            if report:
                                st.components.v1.html(report._repr_html_(), height=800, scrolling=True)
            
            else:
                st.info("Genera suficientes predicciones para realizar análisis de drift (mínimo 10 registros).")
        
        with tab3:
            st.header("Evolución Temporal")
            
            if os.path.exists(MONITOR_LOG):
                logged_data = pd.read_csv(MONITOR_LOG)
                
                if len(logged_data) > 10:
                    # Seleccionar variable para análisis temporal
                    numeric_features = [col for col in all_features if pd.api.types.is_numeric_dtype(X_ref[col])]
                    
                    if numeric_features:
                        selected_feature = st.selectbox(
                            "Seleccionar variable para análisis temporal:",
                            numeric_features
                        )
                        
                        window_days = st.slider("Ventana de análisis (días):", 1, 30, 7)
                        
                        result = analyze_temporal_drift(logged_data, selected_feature, window_days)
                        
                        if result:
                            fig_temporal, stats_df = result
                            st.plotly_chart(fig_temporal, use_container_width=True)
                            
                            # Mostrar estadísticas
                            st.subheader("Estadísticas Temporales")
                            st.dataframe(stats_df, use_container_width=True)
                            
                            # Análisis de tendencias
                            st.subheader("🔍 Análisis de Tendencias")
                            
                            if len(stats_df) >= 3:
                                # Calcular tendencia lineal
                                x = np.arange(len(stats_df))
                                y = stats_df['mean'].values
                                
                                if not np.all(np.isnan(y)):
                                    mask = ~np.isnan(y)
                                    if np.sum(mask) >= 2:
                                        slope, intercept = np.polyfit(x[mask], y[mask], 1)
                                        
                                        col1, col2 = st.columns(2)
                                        
                                        with col1:
                                            if slope > 0:
                                                st.success(f"📈 Tendencia ascendente: {slope:.4f} por día")
                                            elif slope < 0:
                                                st.warning(f"📉 Tendencia descendente: {slope:.4f} por día")
                                            else:
                                                st.info("➡️ Tendencia estable")
                                        
                                        with col2:
                                            volatility = stats_df['std'].mean()
                                            if volatility > stats_df['mean'].mean() * 0.5:
                                                st.warning(f"⚠️ Alta volatilidad: {volatility:.4f}")
                                            else:
                                                st.success(f"✅ Volatilidad moderada: {volatility:.4f}")
                    else:
                        st.info("No hay variables numéricas para análisis temporal.")
                else:
                    st.info("Se necesitan más datos para análisis temporal (mínimo 10 registros).")
            else:
                st.info("No hay datos de monitoreo disponibles.")
        
        with tab4:
            st.header("Métricas de Performance")
            
            if os.path.exists(MONITOR_LOG):
                logged_data = pd.read_csv(MONITOR_LOG)
                
                if 'actual' in logged_data.columns and 'prediction' in logged_data.columns:
                    # Filtrar datos completos
                    performance_data = logged_data.dropna(subset=['actual', 'prediction'])
                    
                    if len(performance_data) > 0:
                        y_true = performance_data['actual']
                        y_pred = performance_data['prediction']
                        
                        # Convertir probabilidades a clases
                        y_pred_class = (y_pred > 0.5).astype(int)
                        
                        # Calcular métricas
                        col1, col2, col3, col4 = st.columns(4)
                        
                        with col1:
                            try:
                                accuracy = accuracy_score(y_true, y_pred_class)
                                st.metric("Accuracy", f"{accuracy:.3f}")
                            except:
                                st.metric("Accuracy", "N/A")
                        
                        with col2:
                            try:
                                auc = roc_auc_score(y_true, y_pred)
                                st.metric("AUC-ROC", f"{auc:.3f}")
                            except:
                                st.metric("AUC-ROC", "N/A")
                        
                        with col3:
                            try:
                                f1 = f1_score(y_true, y_pred_class)
                                st.metric("F1-Score", f"{f1:.3f}")
                            except:
                                st.metric("F1-Score", "N/A")
                        
                        with col4:
                            try:
                                precision = (y_true * y_pred_class).sum() / max(y_pred_class.sum(), 1)
                                st.metric("Precision", f"{precision:.3f}")
                            except:
                                st.metric("Precision", "N/A")
                        
                        # Matriz de confusión
                        st.subheader("📊 Matriz de Confusión")
                        
                        cm = confusion_matrix(y_true, y_pred_class)
                        
                        fig_cm = ff.create_annotated_heatmap(
                            z=cm,
                            x=['Pred 0', 'Pred 1'],
                            y=['Real 0', 'Real 1'],
                            colorscale='Blues',
                            showscale=True,
                            annotation_text=cm.astype(str)
                        )
                        
                        fig_cm.update_layout(
                            title="Matriz de Confusión",
                            height=400
                        )
                        
                        st.plotly_chart(fig_cm, use_container_width=True)
                        
                        # Gráfico ROC
                        st.subheader("📈 Curva ROC")
                        
                        from sklearn.metrics import roc_curve
                        
                        fpr, tpr, thresholds = roc_curve(y_true, y_pred)
                        
                        fig_roc = go.Figure()
                        fig_roc.add_trace(go.Scatter(
                            x=fpr, y=tpr,
                            mode='lines',
                            name=f'ROC (AUC = {auc:.3f})',
                            line=dict(color='blue', width=2)
                        ))
                        
                        fig_roc.add_trace(go.Scatter(
                            x=[0, 1], y=[0, 1],
                            mode='lines',
                            name='Random',
                            line=dict(color='red', width=1, dash='dash')
                        ))
                        
                        fig_roc.update_layout(
                            title='Curva ROC',
                            xaxis_title='False Positive Rate',
                            yaxis_title='True Positive Rate',
                            height=400
                        )
                        
                        st.plotly_chart(fig_roc, use_container_width=True)
                        
                    else:
                        st.info("No hay datos completos para calcular métricas de performance.")
                else:
                    st.info("Para ver métricas de performance, se necesitan tanto predicciones como valores reales ('actual').")
            else:
                st.info("No hay datos de monitoreo disponibles.")
        
        with tab5:
            st.header("📋 Logs de Monitoreo")
            
            if os.path.exists(MONITOR_LOG):
                logged_data = pd.read_csv(MONITOR_LOG)
                
                # Mostrar últimas predicciones
                st.subheader("Últimas Predicciones")
                
                show_rows = st.selectbox("Mostrar últimas filas:", [10, 25, 50, 100, 500], index=1)
                
                # Ordenar por timestamp si existe
                if 'timestamp' in logged_data.columns:
                    logged_data_display = logged_data.sort_values('timestamp', ascending=False)
                else:
                    logged_data_display = logged_data
                
                st.dataframe(logged_data_display.head(show_rows), use_container_width=True)
                
                # Estadísticas del log
                st.subheader("📊 Estadísticas del Log")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Resumen Numérico:**")
                    st.write(logged_data.describe())
                
                with col2:
                    st.write("**Información General:**")
                    
                    info_data = {
                        'Total registros': len(logged_data),
                        'Variables': len(logged_data.columns),
                        'Fecha inicio': logged_data['timestamp'].min() if 'timestamp' in logged_data else 'N/A',
                        'Fecha fin': logged_data['timestamp'].max() if 'timestamp' in logged_data else 'N/A',
                        'Registros con valores reales': logged_data['actual'].count() if 'actual' in logged_data else 0
                    }
                    
                    for key, value in info_data.items():
                        st.write(f"**{key}:** {value}")
                
                # Botones de acción
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    csv = logged_data.to_csv(index=False)
                    st.download_button(
                        label="📥 Descargar CSV Completo",
                        data=csv,
                        file_name=f"monitoring_log_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv",
                        type="primary"
                    )
                
                with col2:
                    if st.button("🔄 Actualizar Vista", type="secondary"):
                        st.rerun()
                
                with col3:
                    if st.button("🗑️ Limpiar Log", type="secondary"):
                        if os.path.exists(MONITOR_LOG):
                            os.remove(MONITOR_LOG)
                            st.success("Log eliminado exitosamente")
                            time.sleep(1)
                            st.rerun()
                
                # Análisis de calidad de datos
                st.subheader("🔍 Calidad de Datos")
                
                if len(logged_data) > 0:
                    quality_metrics = {}
                    
                    for col in logged_data.columns:
                        null_pct = logged_data[col].isnull().mean() * 100
                        unique_vals = logged_data[col].nunique()
                        
                        quality_metrics[col] = {
                            'Null %': f"{null_pct:.1f}%",
                            'Unique Values': unique_vals,
                            'Data Type': str(logged_data[col].dtype)
                        }
                    
                    quality_df = pd.DataFrame(quality_metrics).T.reset_index()
                    quality_df.columns = ['Variable', '% Nulos', 'Valores Únicos', 'Tipo de Dato']
                    
                    st.dataframe(quality_df, use_container_width=True)
            
            else:
                st.info("No hay logs disponibles. Genera predicciones para comenzar.")
        
        # Footer
        st.divider()
        st.markdown("---")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.caption(f"📅 Última actualización: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        with col2:
            st.caption(f"📊 Total variables monitoreadas: {len(all_features)}")
        
        with col3:
            st.caption(f"🔗 API: {API_URL}")
    
    else:
        st.warning("⚠️ Por favor, carga los datos usando el botón en la sidebar.")

# ================================
# 11. Ejecutar aplicación
# ================================
if __name__ == "__main__":
    main()